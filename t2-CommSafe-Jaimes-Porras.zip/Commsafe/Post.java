
/**
 * Write a description of class Post here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Post
{
    // instance variables - replace the example below with your own
    private String descripcion;
    private String ubicacion;

    /**
     * Constructor for objects of class Post
     */
    public Post()
    {
        // initialise instance variables
        
    }
}
