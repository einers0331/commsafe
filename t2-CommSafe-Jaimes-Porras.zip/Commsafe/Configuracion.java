
/**
 * Write a description of class Configuracion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Configuracion
{
    // instance variables - replace the example below with your own
    private Sesion sesion;

    /**
     * Constructor for objects of class Configuracion
     */
    public Configuracion()
    {
        // initialise instance variables
    }
}
