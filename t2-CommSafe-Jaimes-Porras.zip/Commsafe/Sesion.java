
/**
 * Write a description of class Sesion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sesion
{
    // instance variables - replace the example below with your own
    private Registro registro;
    private Ciudadano ciudadano;

    /**
     * Constructor for objects of class Sesion
     */
    public Sesion()
    {
        // initialise instance variables     
    }
}
