
/**
 * Write a description of class Muro here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.ArrayList;
public class Muro
{
    // instance variables - replace the example below with your own
    private ArrayList<Post> posts = new ArrayList<>();
    private Sesion sesion;

    /**
     * Constructor for objects of class Muro
     */
    public Muro()
    {
        // initialise instance variables
    }
}
